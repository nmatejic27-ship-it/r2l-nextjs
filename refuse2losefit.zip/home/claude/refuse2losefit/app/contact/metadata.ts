import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact",
  description: "Get in touch with Refuse2LoseFIT. We respond within 24 hours.",
};
